#ifndef PATH_H
#define PATH_H

char *init_path();
int path_cmd(char **command_arguments, char **path);

#endif
