/*

 Team Name: Team 8 - (SysForge)

 Members Names: Colten Mikulastik, Mayuresh Keshav Kamble, Nathanlie Ortega, and Igor Leeck

 Course: CSCE 3600.002


 Description: This is main.c that contains the core shell loop and helper functions.

 */

#define _GNU_SOURCE
#include <unistd.h>
#include "shell.h"

static pid_t shell_pgid;

 char** inputParse(char *input_line)
 {
    int bufferCap = MAXIMUM_ARGUMENT_COUNT;
    int curPosition = 0;
    char **tokenArray = malloc(bufferCap * sizeof(char*));
    char *singleToken;

    if (!tokenArray)
    {
        fprintf(stderr, "newshell: memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    singleToken = strtok(input_line, " \t\r\n\a");

    while (singleToken != NULL)
     {
        tokenArray[curPosition] = singleToken;
        curPosition++;

        if (curPosition >= bufferCap)
        {
            bufferCap += MAXIMUM_ARGUMENT_COUNT;

            tokenArray = realloc(tokenArray, bufferCap * sizeof(char*));

            if (!tokenArray)
            {
                fprintf(stderr, "newshell: memory allocation error\n");

                exit(EXIT_FAILURE);
            }
        }

        singleToken = strtok(NULL, " \t\r\n\a");
    }

    tokenArray[curPosition] = NULL;

    return tokenArray;
}



void deallocateArgument(char **command_arguments)
{
    if (command_arguments)
    {
        free(command_arguments);

    }
}



int procExecuteCommand(char **command_arguments, char **shell_path)
{
    pid_t childPid;
    int childStatus;
    char *aliasSubCmd;
    char *aliasCopy;
    char **subArgArray;
    int execResult;

    if (command_arguments[0] == NULL)
    {
        return 1;           //This return when user pressed enter with no command.

    }

    // find and replace our fd from given input
    // find_and_replace_fd(command_arguments);

    //Cd Command and Alias Support (Nathanlie Ortega):

    //This is to check for "cd" Built-in command
    if (strcmp(command_arguments[0], "cd") == 0)
    {
        executeCD(command_arguments);
        return 1;
    }

    //This is to check for "alias" Advanced Features
    if (strcmp(command_arguments[0], "alias") == 0)
    {
        executeAlias(command_arguments);
        return 1;
    }


    //This is to check if first word is an alias
    aliasSubCmd = findAlias(command_arguments[0]);

    if (aliasSubCmd != NULL)
    {
        // Make a copy because inputParse modifies the string with strtok
        aliasCopy = strdup(aliasSubCmd);
        free(aliasSubCmd);

        if (aliasCopy == NULL)
        {
            perror("strdup");
            return 1;
        }

        subArgArray = inputParse(aliasCopy);

        //This will execute the substituted command recursively.
        execResult = procExecuteCommand(subArgArray, shell_path);
        deallocateArgument(subArgArray);
        free(aliasCopy);
        return execResult;

    }



    //Colten - path command and I/O redirection
    if (strcmp(command_arguments[0], "path") == 0)
    {
        path_cmd(command_arguments, shell_path);
        return 1;
    }



    //Mayuresh - exit command (Integrated by Mayuresh Keshav Kamble)
    if (isExitCommand(command_arguments))
    {
        return executeExit(command_arguments);
    }



    //Igor - myhistory
    if (strcmp(command_arguments[0], "myhistory") == 0) {
	executeMyHistory(command_arguments);
	return 1;
    }


    //External command execution using fork() and execvp() system calls
     childPid = fork();      // A child process to execute

     //child
     if (childPid == 0)
     {


	//restore signal handling
	signal(SIGINT, SIG_DFL);
	signal(SIGTSTP, SIG_DFL);
	signal(SIGTSTP, SIG_DFL);

	//put child in its own group and in the foreground
	setpgid(0, 0);
	tcsetpgrp(STDIN_FILENO, getpid());

        find_and_replace_fd(command_arguments);

         if (execvp(command_arguments[0], command_arguments) == -1)
         {
             perror("newshell");
         }

         exit(EXIT_FAILURE);

     }

     else if (childPid < 0)
     {

         perror("newshell");
     }

     //parent
     else
     {

	 //Igor
	 setpgid(childPid, childPid);
         //giving control to child
	 tcsetpgrp(STDIN_FILENO, childPid);


         do
         {
             waitpid(childPid, &childStatus, WUNTRACED);       //This is parent waiting for child to complete.
         } while (!WIFEXITED(childStatus) && !WIFSIGNALED(childStatus));

	tcsetpgrp(STDIN_FILENO, shell_pgid);
	fflush(stdout);
     }

    return 1;
}


//This is the main shell point...
int main(int argc, char **argv)
{
    char *userInput = NULL;
    size_t bufferSize = 0;
    char **parsedArgs;
    int shouldContinue = 1;
    char *pipelineCopy;
    char *pipeCommands[4];
    int pipeCount;
    int i;

    //This is to show the suppress compiler warnings for unused parameters
    (void)argc;
    (void)argv;


    //Initializations

    initializeAlias();          //This will initialize "Alias Support" (Nathanlie Ortega).


    //Colten - Initialize path system
    char *shell_path = init_path();
    // get some memory to store the path dynamically
    // create pointer on heap, create string on heap
    char **variant_shell_path = (char **)malloc(sizeof(char *));
    char *hidden_dragon = (char *)malloc(sizeof(char) * (strlen(shell_path) + 1));
    // copy over the data in our shell_path init
    memcpy(hidden_dragon, shell_path, strlen(shell_path) + 1);
    // assign our heap pointer to the path
    *variant_shell_path = hidden_dragon;



    //Initialize myhistory system
    initHistory();

    //Ignore signals for the shell process for its child processes to handle
    ignore_signals();

    //put the shell in its own process group for the child processes to join
    shell_pgid = getpid();
    if (setpgid(shell_pgid, shell_pgid) < 0) {
        perror("setpgid");
        exit(EXIT_FAILURE);
    }

    // Make shell the foreground process for the terminal
    if (tcsetpgrp(STDIN_FILENO, shell_pgid) < 0) {
        perror("tcsetpgrp");
        exit(EXIT_FAILURE);
    }



    printf("newshell - Team 8 Shell\n");
    printf("Type 'exit' to quit\n\n");

    //The main command processing loop
    do
    {
        printf("newshell> ");

        //This will read user input from stdin.
        if (getline(&userInput, &bufferSize, stdin) == -1)

        {
            if (feof(stdin))
            {
                printf("\nType 'exit' to leave the shell.\n");
		clearerr(stdin);
		continue;
            }

            else
            {
                perror("getline");
                exit(EXIT_FAILURE);
            }
        }

	//Igor - added to the history to be executed on by myhistory
	if(userInput[0] != '\0' && userInput[0] != '\n' && userInput[0] != ' ') {
	    write_history(userInput);
	}


        //Mayuresh - Check for pipeline commands (Integrated by Mayuresh Keshav Kamble)
        if (has_pipe(userInput))
        {
            pipelineCopy = strdup(userInput);
            if (pipelineCopy != NULL)
            {
                pipeCount = split_pipeline(pipelineCopy, pipeCommands, 4);

                if (pipeCount > 0)
                {
                    execute_pipeline(pipeCommands, pipeCount);

                    //Free allocated memory
                    for (i = 0; i < pipeCount; i++)
                    {
                        free(pipeCommands[i]);
                    }
                }
                free(pipelineCopy);
            }
        }
        else
        {
            //No pipeline, process normally
            parsedArgs = inputParse(userInput);        //This is the parse input into command arguments.

            shouldContinue = procExecuteCommand(parsedArgs, variant_shell_path);      //This will execute the command.

            deallocateArgument(parsedArgs);                    //This will free the argument array.
        }


        //Mayuresh - Check if exit flag was set (Integrated by Mayuresh Keshav Kamble)
        if (should_exit_flag)
        {
            shouldContinue = 0;
        }

    }

    while (shouldContinue);


    free(userInput);          //This will cleanup before exit.
    free(*variant_shell_path); //also needs to be free'd
    free(variant_shell_path);


    return EXIT_SUCCESS;

}
